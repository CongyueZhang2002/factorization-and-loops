<|"MasterIndex" -> 64, "Master" -> GLI[TopologyF10C25N1, 
   {1, 1, 2, 0, 0, 1, 0, 1, 0}], "ShardCount" -> 256, "TargetCount" -> 44877, 
 "KiraRuleCount" -> 44648, "SelectedContributionCount" -> 1129, 
 "CatalogueContributionCount" -> 1129, "CoefficientRemainderZero" -> True, 
 "KiraRemaindersZero" -> True, "KiraTerminalsDeclaredMasters" -> True, 
 "TargetSetComplete" -> True, "ScalePower" -> "DetermineAfterSummation", 
 "FixedAnalyticFactor" -> Pi^3*\[Alpha]s^4, "ExpectedAnalyticMonomial" -> 
  qPiEpsilon^2*qTwoEpsilon^4, "Seconds" -> 111.029752, 
 "SourceBytes" -> 20223176, "RationalBytes" -> 12843616, 
 "ExpressionFile" -> "/home/maxzhang/FACET/Codex/ppHX_NNLO_DoubleReal/FiniteF\
ieldReconstruction/Overnight_2026-08-09/NNLOMaster0064SourceComposition.expr"\
, "ExpressionFileBytes" -> 809367, "ExpressionFileHash" -> 
  "ac170b36603052ddbd3d106c9fbe77c9165658e590dc992781e5b5afb28cdd1d", 
 "RegisteredVariables" -> {eps, ca, cf, s, x, y, ya, yb, yh, q2, qp}, 
 "PhysicalTargetManifestHash" -> 
  "92aac74cb6ac4757677a14b7ee270f026424e8e2fe75a6cd994a8c5ae98f7ff2", 
 "KiraManifestHash" -> 
  "66954d21aa6ed3c7c07470e158189ce5f5926fcba56fd35d85b8841dfcaa964d", 
 "ExactData" -> True|>
