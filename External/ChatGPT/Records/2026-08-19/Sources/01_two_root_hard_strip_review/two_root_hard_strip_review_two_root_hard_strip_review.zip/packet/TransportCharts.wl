(* Stage 2: the catalog of rationalizing charts, the per-family chart
   assignment, and the composition of a class record's own chart with a
   target chart.

   WHY (measured 2026-08-17, coordinator census over all 91 families;
   scratch chart_census / conic_census / alphabet missions, recorded in
   TransportProductionPlan.md):

     * 20 conic-chart classes and 3 two-variable classes need a SQUARE
       ROOT to have a rational eps-form; only FIVE distinct quadratics
       occur:
           lambda1 = (1-v-w)^2 - 4 v w          (Kallen; classes 26,49,95,101,
                                                  130,165,166,171; two-var 77,97)
           lambda2 = lambda1(-v, w)              (classes 33,62,80,118,122,123;
                                                  two-var 79)
           lambda3 = lambda1(v, -w)              (classes 75,90,91,92,93)
           4 v + w^2                             (class 98; v^2 + 4 w for its
                                                  v<->w members)
           1 - 4 v w                             (class 115, one-variable u)
       and a class member may carry the v<->w image of its
       representative's quadratic (measured: CF53/CF57 host classes
       90/93/91 with lambda2, CF48/CF52 host class 98 with v^2 + 4 w).
     * A family needs ONE chart in which every class form it hosts is
       rational.  Single-root families take the chart of their root;
       two-root families take a JOINT chart built on the Kallen chart by
       a rational point on the second conic (derived and verified
       exactly 2026-08-17 01:42, pool mission jcharts2); the three
       triple-root families (CF259, CF300, CF303) are not covered here
       yet.
     * Polynomial letters that are quadratic in the moving path variable
       in every rational chart (1 - w + v w in the Kallen chart is a
       (2,2)-curve on P^1 x P^1) are handled by ALGEBRAIC LETTERS
       (MasterTransport.wl, masterTransportMonicCheck), not by charts.
       Charts exist to make the block transformations rational, nothing
       else.

   Every chart in the catalog carries the exact identities that license
   it (root^2 == RootSquare o Subst, Jacobian nondegenerate) and
   TransportChartVerify re-derives them; nothing is believed from the
   record.

   Physics bookkeeping (chamber, branch, sign of the root) is NOT done
   here -- same discipline as TransportFamilyInChart: the chart and its
   Jacobian determinant are recorded so that stage 3 can choose. *)

ClearAll[
  TransportChartCatalog,
  TransportChartVerify,
  TransportFamilyChartTable,
  TransportFamilyChart,
  masterTransportChartByName,
  masterTransportComposeTwoVariableRecord
];



(* the source variables and the chart variables, by NAME; callers
   re-key by SymbolName as everywhere in this module *)
$transportChartV = Symbol["Global`v"];
$transportChartW = Symbol["Global`w"];
$transportChartX = Symbol["Global`x"];
$transportChartY = Symbol["Global`y"];
$transportChartS = Symbol["Global`s"];
$transportChartU = Symbol["Global`u"];
$transportChartP = Symbol["Global`p"];

transportChartLambda1[v_, w_] := (1 - v - w)^2 - 4 v w;
transportChartLambda2[v_, w_] := transportChartLambda1[-v, w];
transportChartLambda3[v_, w_] := transportChartLambda1[v, -w];

TransportChartCatalog[] := With[
  {v = $transportChartV, w = $transportChartW, x = $transportChartX,
   y = $transportChartY, s = $transportChartS, u = $transportChartU,
   p = $transportChartP},
  Module[{k1, k2, k3, q4a, q4b, b115, k12, k13, k23, x12, x13, x23},
  (* ---- single-root charts ------------------------------------------ *)
  k1 = <|"Name" -> "Kallen1", "Kind" -> "TwoVariable", "Variables" -> {x, y},
    "Subst" -> {v -> x y, w -> (1 - x) (1 - y)},
    "Root" -> x - y, "RootSquare" -> transportChartLambda1[v, w],
    "Roots" -> {<|"Root" -> x - y, "RootSquare" -> transportChartLambda1[v, w]|>},
    "Notes" -> "the class-97/77 chart; sqrt(lambda1) = x - y; Jacobian det x - y"|>;
  k2 = <|"Name" -> "Kallen2", "Kind" -> "TwoVariable", "Variables" -> {x, y},
    "Subst" -> {v -> -x y, w -> (1 - x) (1 - y)},
    "Root" -> x - y, "RootSquare" -> transportChartLambda2[v, w],
    "Roots" -> {<|"Root" -> x - y, "RootSquare" -> transportChartLambda2[v, w]|>},
    "Notes" -> "the class-79 chart; lambda2(v,w) = lambda1(-v,w) = (x-y)^2"|>;
  k3 = <|"Name" -> "Kallen3", "Kind" -> "TwoVariable", "Variables" -> {x, y},
    "Subst" -> {v -> x y, w -> -(1 - x) (1 - y)},
    "Root" -> x - y, "RootSquare" -> transportChartLambda3[v, w],
    "Roots" -> {<|"Root" -> x - y, "RootSquare" -> transportChartLambda3[v, w]|>},
    "Notes" -> "lambda3(v,w) = lambda1(v,-w) = (x-y)^2"|>;
  (* The Q4 charts keep the OTHER kinematic variable as a chart
     variable (v = p or w = p) and rationalize the root through the
     conic parametrization w = (p - s^2)/s (resp. v = ...), so that
     4v + w^2 = ((p + s^2)/s)^2.  MEASURED 2026-08-17 (chart probes on
     CF48/CF232): the naive parametrization v = (s^2 - u^2)/4, w = u
     turns the letter v + w - w^2 of CF48/CF52 into a QUARTIC in the
     path variable (not admissible as algebraic letters); with p linear
     in the frozen variable every letter of these families is of degree
     <= 2 in s (letters quadratic in s: roots algebraic in p, admissible). *)
  q4a = <|"Name" -> "Q4a", "Kind" -> "TwoVariable", "Variables" -> {p, s},
    "Subst" -> {v -> p, w -> (p - s^2)/s},
    "Root" -> (p + s^2)/s, "RootSquare" -> 4 v + w^2,
    "Roots" -> {<|"Root" -> (p + s^2)/s, "RootSquare" -> 4 v + w^2|>},
    "Notes" -> "class 98 (Fixed w, v = (t^2 - w^2)/4, Root t): t = (p + s^2)/s; Jacobian det -(p + s^2)/s^2"|>;
  q4b = <|"Name" -> "Q4b", "Kind" -> "TwoVariable", "Variables" -> {p, s},
    "Subst" -> {v -> (p - s^2)/s, w -> p},
    "Root" -> (p + s^2)/s, "RootSquare" -> v^2 + 4 w,
    "Roots" -> {<|"Root" -> (p + s^2)/s, "RootSquare" -> v^2 + 4 w|>},
    "Notes" -> "class 98 for its v<->w members (CF48, CF52); Jacobian det (p + s^2)/s^2"|>;
  b115 = <|"Name" -> "Bilinear115", "Kind" -> "TwoVariable", "Variables" -> {p, u},
    "Subst" -> {v -> p, w -> (1 - u^2)/(4 p)},
    "Root" -> u, "RootSquare" -> 1 - 4 v w,
    "Roots" -> {<|"Root" -> u, "RootSquare" -> 1 - 4 v w|>},
    "Notes" -> "class 115 (one-variable in u, u^2 = 1 - 4 v w); Jacobian det -u/(2p)"|>;
  (* ---- joint charts (derived 2026-08-17 by a rational point on the
          second conic in the base Kallen chart, verified exactly) ------ *)
  x12 = -2 (-3 y + s y + 2 y^2)/(-1 + s^2 + 4 y - 4 y^2);
  k12 = <|"Name" -> "Kallen12", "Kind" -> "TwoVariable", "Variables" -> {y, s},
    "Subst" -> {v -> Together[x12 y], w -> Together[(1 - x12) (1 - y)]},
    "Root" -> Together[x12 - y], "RootSquare" -> transportChartLambda1[v, w],
    "Roots" -> {
      <|"Root" -> Together[x12 - y], "RootSquare" -> transportChartLambda1[v, w]|>,
      <|"Root" -> Together[y + s x12], "RootSquare" -> transportChartLambda2[v, w]|>},
    "Parents" -> <|"Kallen1" -> {x -> x12, y -> y}|>,
    "Notes" -> "Kallen1 base; the line z = y + s x through the rational point \
(x, z) = (0, y) of z^2 = lambda2|_{Kallen1}; sqrt(lambda1) = x - y, \
sqrt(lambda2) = y + s x"|>;
  x13 = (1 + s) (-3 + s + 2 y)/(-1 + s^2 + 4 y - 4 y^2);
  k13 = <|"Name" -> "Kallen13", "Kind" -> "TwoVariable", "Variables" -> {y, s},
    "Subst" -> {v -> Together[x13 y], w -> Together[(1 - x13) (1 - y)]},
    "Root" -> Together[x13 - y], "RootSquare" -> transportChartLambda1[v, w],
    "Roots" -> {
      <|"Root" -> Together[x13 - y], "RootSquare" -> transportChartLambda1[v, w]|>,
      <|"Root" -> Together[(1 - y) + s (x13 - 1)], "RootSquare" -> transportChartLambda3[v, w]|>},
    "Parents" -> <|"Kallen1" -> {x -> x13, y -> y}|>,
    "Notes" -> "Kallen1 base; the line z = (1-y) + s (x-1) through the rational \
point (x, z) = (1, 1-y) of z^2 = lambda3|_{Kallen1}"|>;
  x23 = (-3 + s) (1 + s - 2 y)/(-1 + s^2);
  k23 = <|"Name" -> "Kallen23", "Kind" -> "TwoVariable", "Variables" -> {y, s},
    "Subst" -> {v -> Together[-x23 y], w -> Together[(1 - x23) (1 - y)]},
    "Root" -> Together[x23 - y], "RootSquare" -> transportChartLambda2[v, w],
    "Roots" -> {
      <|"Root" -> Together[x23 - y], "RootSquare" -> transportChartLambda2[v, w]|>,
      <|"Root" -> Together[(1 + y) + s (x23 - 1)], "RootSquare" -> transportChartLambda3[v, w]|>},
    "Parents" -> <|"Kallen2" -> {x -> x23, y -> y}|>,
    "Notes" -> "Kallen2 base; the line z = (1+y) + s (x-1) through the rational \
point (x, z) = (1, 1+y) of z^2 = lambda3|_{Kallen2}"|>;
  <|"Kallen1" -> k1, "Kallen2" -> k2, "Kallen3" -> k3, "Q4a" -> q4a, "Q4b" -> q4b,
    "Bilinear115" -> b115, "Kallen12" -> k12, "Kallen13" -> k13, "Kallen23" -> k23|>
]];

masterTransportChartByName[name_String] := Lookup[TransportChartCatalog[], name, None];

(* exact re-derivation of what a chart record claims *)
TransportChartVerify[chart_Association] := With[
  {v = $transportChartV, w = $transportChartW},
  Module[{vars, subst, f, g, jac, det, roots, rootChecks, parents, parentChecks, ok},
    vars = chart["Variables"]; subst = chart["Subst"];
    {f, g} = Together /@ (Last /@ subst);
    jac = {{D[f, vars[[1]]], D[f, vars[[2]]]}, {D[g, vars[[1]]], D[g, vars[[2]]]}};
    det = Together[Det[jac]];
    roots = Lookup[chart, "Roots", {<|"Root" -> chart["Root"], "RootSquare" -> chart["RootSquare"]|>}];
    rootChecks = Table[
      TrueQ[Together[r["Root"]^2 - (r["RootSquare"] /. {v -> f, w -> g})] === 0],
      {r, roots}];
    parents = Lookup[chart, "Parents", <||>];
    parentChecks = Association @ KeyValueMap[
      Function[{parentName, map},
        Module[{parent = masterTransportChartByName[parentName], pf, pg},
          If[parent === None, parentName -> False,
            {pf, pg} = Last /@ parent["Subst"];
            parentName -> (TrueQ[Together[(pf /. map) - f] === 0] &&
              TrueQ[Together[(pg /. map) - g] === 0])]]],
      parents];
    ok = AllTrue[rootChecks, TrueQ] && ! TrueQ[det === 0] &&
      AllTrue[Values[parentChecks], TrueQ];
    <|"OK" -> ok, "Name" -> Lookup[chart, "Name", "?"], "RootIdentities" -> rootChecks,
      "JacobianDet" -> Factor[det], "ParentMaps" -> parentChecks|>]];

(* The per-family chart assignment.  MEASURED 2026-08-17 from the class
   assignment (BlockClasses/block_class_assign.wl), the class-form
   charts, and each family's raw alphabet (which decides the v<->w
   orientation of a member's quadratic).  Root-free families are absent
   and transport in (v,w).  The three triple-root families are listed
   with Missing so that a caller cannot silently pick a wrong chart. *)
TransportFamilyChartTable[] := <|
  (* lambda1 only *)
  "CF13" -> "Kallen1", "CF20" -> "Kallen1", "CF24" -> "Kallen1", "CF26" -> "Kallen1",
  "CF230" -> "Kallen1", "CF258" -> "Kallen1", "CF264" -> "Kallen1", "CF88" -> "Kallen1",
  "CF98" -> "Kallen1", "CF384" -> "Kallen1", "CF388" -> "Kallen1", "CF407" -> "Kallen1",
  "CF50" -> "Kallen1", "CF56" -> "Kallen1",
  (* lambda2 only (incl. v<->w members of lambda3 classes) *)
  "CF18" -> "Kallen2", "CF21" -> "Kallen2", "CF23" -> "Kallen2", "CF33" -> "Kallen2",
  "CF53" -> "Kallen2", "CF57" -> "Kallen2", "CF91" -> "Kallen2", "CF97" -> "Kallen2",
  "CF413" -> "Kallen2", "CF416" -> "Kallen2", "CF420" -> "Kallen2",
  (* lambda3 only *)
  "CF248" -> "Kallen3", "CF253" -> "Kallen3",
  (* 4 v + w^2 and its v<->w image *)
  "CF260" -> "Q4a", "CF48" -> "Q4b", "CF52" -> "Q4b",
  (* 1 - 4 v w *)
  "CF299" -> "Bilinear115",
  (* two roots *)
  "CF232" -> "Kallen12", "CF236" -> "Kallen12", "CF240" -> "Kallen12", "CF319" -> "Kallen12",
  "CF321" -> "Kallen12", "CF385" -> "Kallen12", "CF408" -> "Kallen12",
  "CF249" -> "Kallen13", "CF254" -> "Kallen13", "CF265" -> "Kallen13",
  "CF226" -> "Kallen23", "CF231" -> "Kallen23", "CF305" -> "Kallen23",
  (* three roots: not covered by this catalog *)
  "CF259" -> Missing["NotCovered", "lambda1 + lambda3 + (4v+w^2)"],
  "CF300" -> Missing["NotCovered", "lambda2 + lambda3 + (1-4vw)"],
  "CF303" -> Missing["NotCovered", "lambda2 + lambda3 + (1-4vw)"]
|>;

TransportFamilyChart[family_String] := Module[{entry},
  entry = Lookup[TransportFamilyChartTable[], family, None];
  Which[
    entry === None, None,
    MissingQ[entry], entry,
    True, masterTransportChartByName[entry]]];

(* Compose a class record written in ITS OWN two-variable chart with a
   TARGET two-variable chart that rationalizes the record's root:
   solve the record's substitution for the record's variables using the
   target chart's rational root for the same quadratic (both signs), and
   accept a candidate only if the record's Subst at that candidate
   reproduces the target Subst EXACTLY.  Uses the kernel's Solve; the
   acceptance is the identity, never Solve's return shape.

   record chart:  <|"Variables" -> {x', y'}, "Subst" -> {v -> f(x',y'), w -> g(x',y')},
                    "Root" -> rho(x',y'), "RootSquare" -> Q(v,w)|>
   target data:   masterTransportChartData's record ("Subst", "Variables",
                  "Roots" or "Root"/"RootSquare")
   Returns <|"Status" -> "OK", "Map" -> {x' -> ..., y' -> ...}, "Images" -> {...},
             "Sign" -> +-1|> or a named refusal. *)
masterTransportComposeTwoVariableRecord[recordChart_Association,
    targetData_Association, sourceVariables_List] := Module[
  {recVars, recSubst, recRoot, recSquare, tgtVars, tgtSubst, tf, tg, tgtRoots,
   matching, candidates, verified, eqs, sols},
  recVars = Lookup[recordChart, "Variables", $Failed];
  recSubst = Lookup[recordChart, "Subst", $Failed];
  recRoot = Lookup[recordChart, "Root", None];
  recSquare = Lookup[recordChart, "RootSquare", None];
  If[! MatchQ[recVars, {_Symbol, _Symbol}] || ! MatchQ[recSubst, {_Rule, _Rule}],
    Return[<|"Status" -> "RecordChartNotWellFormed"|>]];
  tgtVars = targetData["Variables"];
  {tf, tg} = Together /@ (Last /@ targetData["Subst"]);
  tgtRoots = Lookup[targetData, "Roots", None];
  If[! ListQ[tgtRoots],
    tgtRoots = If[Lookup[targetData, "Root", None] === None, {},
      {<|"Root" -> targetData["Root"], "RootSquare" -> targetData["RootSquare"]|>}]];
  (* the target root that rationalizes the RECORD's quadratic *)
  matching = If[recSquare === None || recRoot === None, {},
    Select[tgtRoots, TrueQ[Together[#["RootSquare"] - recSquare] === 0] &]];
  (* the record's variables are renamed to FRESH symbols before solving:
     a joint chart keeps the parent's y as its own y, so the record's y
     and the target's y are the same symbol, and Solve would otherwise be
     asked to solve for a symbol that also appears on the right *)
  Module[{fresh, rename, back, fRec, gRec, rhoRec},
    fresh = Table[Unique["masterTransportChartVar"], {2}];
    rename = Thread[recVars -> fresh];
    back = Thread[fresh -> recVars];
    fRec = Last[recSubst[[1]]] /. rename;
    gRec = Last[recSubst[[2]]] /. rename;
    rhoRec = If[recRoot === None, None, recRoot /. rename];
    eqs = {fRec == tf, gRec == tg};
    candidates = If[matching === {},
      (* no root available: try the plain algebraic solve and keep only
         rational solutions *)
      Quiet[Solve[eqs, fresh]],
      (* Table over {root, sign} of Solve's solution LISTS: flatten two
         levels to a plain list of rule lists (one level left each
         candidate as {{rules}} and the identity check below then compared
         a LIST -- measured 2026-08-17 03:20 on class 79 in Kallen23) *)
      Flatten[Table[
        Quiet[Solve[Append[eqs, rhoRec == sign m["Root"]], fresh]],
        {m, matching}, {sign, {1, -1}}], 2]];
    candidates = Select[candidates, FreeQ[#, Power[_, _Rational] | _Root] &];
    verified = Select[candidates,
      TrueQ[Together[(fRec /. #) - tf] === 0] &&
      TrueQ[Together[(gRec /. #) - tg] === 0] &];
    If[verified === {},
      Return[<|"Status" -> "TwoVariableChartsNotComposable",
        "RecordVariables" -> recVars, "TargetVariables" -> tgtVars,
        "MatchingRoots" -> Length[matching], "Candidates" -> Length[candidates]|>]];
    <|"Status" -> "OK",
      "Map" -> Map[Together, First[verified] /. back, {2}],
      "Images" -> Map[Together, fresh /. First[verified]],
      "Candidates" -> Length[candidates], "Verified" -> Length[verified]|>]];

