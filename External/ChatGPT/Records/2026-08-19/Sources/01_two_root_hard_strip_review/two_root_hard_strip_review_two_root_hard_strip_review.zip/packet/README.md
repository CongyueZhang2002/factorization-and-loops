# Two-root hard-strip review packet

This archive accompanies `pro_prompt.md`.

## Exact implementation

- `EpsFormStrip.wl`: current strip solver, including CANONICA searches,
  residue compatibility, Maple `Mratsolde`, exact letter-denominator ansatz,
  and exact two-variable checks.
- `TransportCharts.wl`: exact Kallen-13 and Kallen-23 rationalizing charts and
  their identity checks.
- `family_epsform_sector.wls`: whole-family sector and strip driver.

## Exact problem records

- `CF254_9_8_unsolved.wl`: exported hard strip for the Kallen-13
  representative.
- `blockwise_local_CF231.wl`: Kallen-23 blockwise family record, including the
  first unresolved pair `(8,7)`.

## Measured logs

- `CF254_standardized_run.log`
- `maple_CF254_9_8.log`
- `maple_CF265_14_13.log`
- `maple_CF231_8_7.log`
- `maple_CF305_8_7.log`

The pool logs show process-level outcomes.  They do not prove completion of
the full Maple ansatz grid because the candidate ledger is written only after
the nested search and several jobs ended at the enclosing timeout.
