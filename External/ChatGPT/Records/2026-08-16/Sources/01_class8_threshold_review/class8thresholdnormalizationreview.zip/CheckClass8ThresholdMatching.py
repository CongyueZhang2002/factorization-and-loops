"""Independent exact checks for the Class-8 threshold matching."""

from pathlib import Path

import sympy as sp
from sympy.parsing.mathematica import parse_mathematica


DIRECTORY = Path(__file__).resolve().parent
LOWER_SYSTEM = DIRECTORY / "Class77LowerChartSystem.wl"


def extract_braced_value(text, key):
    start = text.index(f'"{key}" ->')
    opening = text.index("{", start)
    depth = 0
    for index in range(opening, len(text)):
        if text[index] == "{":
            depth += 1
        elif text[index] == "}":
            depth -= 1
            if depth == 0:
                return text[opening : index + 1]
    raise ValueError(f"unclosed value for {key}")


eps = sp.symbols("eps")
lower_text = LOWER_SYSTEM.read_text(encoding="utf-8")
radial_residue = sp.Matrix(
    parse_mathematica(extract_braced_value(lower_text, "RadialResidue"))
)
soft_vector = sp.Matrix(
    parse_mathematica(
        extract_braced_value(lower_text, "TransformedPhysicalSoftVectorOverM2")
    )
)
lower_residue = radial_residue[:7, :7]
lower_characteristic = sp.factor(lower_residue.charpoly().as_expr())

modal_vectors = []
modal_labels = []
for eigenvalue, _, vectors in radial_residue.eigenvects():
    modal_vectors.extend(vectors)
    modal_labels.extend([eigenvalue] * len(vectors))
modal_matrix = sp.Matrix.hstack(*modal_vectors)
modal_coefficients = modal_matrix.inv() * soft_vector


def mode_projection(eigenvalue):
    indices = [
        index
        for index, label in enumerate(modal_labels)
        if sp.simplify(label - eigenvalue) == 0
    ]
    return sum(
        (modal_coefficients[index] * modal_vectors[index] for index in indices),
        sp.zeros(9, 1),
    ).applyfunc(sp.factor)


ordinary_projection = mode_projection(2 * eps)
weighted_hard_projection = mode_projection(3 * eps)
ordinary_coefficient = sp.factor(ordinary_projection[7])
weighted_hard_coefficient = sp.factor(weighted_hard_projection[7])

a0 = sp.gamma(1 - eps) * sp.gamma(1 - 4 * eps) / (
    sp.gamma(1 - 2 * eps) * sp.gamma(1 - 3 * eps)
)
a1 = sp.gamma(1 + eps) * sp.gamma(1 - 4 * eps) / (
    sp.gamma(1 - eps) * sp.gamma(1 - 2 * eps)
)
ratio = -sp.gamma(1 - eps) ** 2 / (
    sp.gamma(1 - 3 * eps) * sp.gamma(1 + eps)
)

ratio_log_through_four = sum(
    (2 - 3**order - (-1) ** order)
    * sp.zeta(order)
    * eps**order
    / order
    for order in range(2, 5)
)
ratio_series = sp.series(-sp.exp(ratio_log_through_four), eps, 0, 5).removeO()
expected_ratio_series = (
    -1 + 2 * sp.pi**2 * eps**2 / 3 + 8 * sp.zeta(3) * eps**3
)
expected_ordinary_coefficient = -3 * (-1 + 3 * eps) / (
    4 * eps**2 * (1 + eps)
)
weighted_coefficient = sp.factor(ratio * ordinary_coefficient)

checks = {
    "lower_source_spectrum": sp.factor(lower_characteristic)
    == sp.Symbol("lambda")
    * (sp.Symbol("lambda") + eps) ** 2
    * (sp.Symbol("lambda") + 3 * eps) ** 2
    * (sp.Symbol("lambda") + 4 * eps) ** 2,
    "no_2eps_source_resonance": sp.simplify(
        (lower_residue - 2 * eps * sp.eye(7)).det(method="domain-ge")
    )
    != 0,
    "no_3eps_source_resonance": sp.simplify(
        (lower_residue - 3 * eps * sp.eye(7)).det(method="domain-ge")
    )
    != 0,
    "threshold_ratio": sp.simplify(ratio + a0 / a1) == 0,
    "regular_threshold_mode_absent": sp.simplify(a0 + a1 * ratio) == 0,
    "ordinary_mode_projection": (
        ordinary_projection
        - ordinary_coefficient
        * sp.Matrix([0, 0, 0, 0, 0, 0, 0, 1, 2])
    ).applyfunc(sp.simplify)
    == sp.zeros(9, 1),
    "weighted_hard_mode_projection": (
        weighted_hard_projection
        - weighted_hard_coefficient
        * sp.Matrix([0, 0, 0, 0, 0, 0, 0, 1, 6])
    ).applyfunc(sp.simplify)
    == sp.zeros(9, 1),
    "ordinary_coefficient": sp.simplify(
        ordinary_coefficient - expected_ordinary_coefficient
    )
    == 0,
    "threshold_ratio_series": sp.expand(ratio_series - expected_ratio_series)
    == 0,
}

for name, value in checks.items():
    print(f"{name}={value}")

print(f"lower_characteristic={lower_characteristic}")
print(f"weighted_to_ordinary_ratio={ratio}")
print(f"ratio_series={ratio_series}")
print(f"ordinary_coefficient_over_M2={ordinary_coefficient}")
print(f"hard_region_weighted_coefficient_over_M2={weighted_hard_coefficient}")
print(f"threshold_weighted_coefficient_over_M2={weighted_coefficient}")

if not all(checks.values()):
    raise SystemExit(2)
