<|"Object" -> "Class77LowerChartSystem", "Coordinates" -> {v, t}, 
 "ChartRule" -> w -> (t*(-1 + t + v))/(-1 + t), 
 "PhysicalChart" -> {0 < v < 1, 0 < t < 1}, 
 "Basis" -> {gli["CF230", {1, 1, 0, 0, 0, 0, 0, 1, 0}], 
   gli["CF230", {1, 1, 0, 0, 0, 0, 1, 1, 0}], 
   gli["CF230", {1, 1, 0, 0, 1, 0, 0, 1, 0}], 
   gli["CF230", {1, 1, 0, 0, 1, 0, 1, 1, 0}], 
   gli["CF230", {1, 1, 0, 0, 1, 0, 1, 2, 0}], 
   gli["CF230", {1, 1, 0, 0, 1, 0, 2, 1, 0}], 
   gli["CF230", {1, 1, 0, 0, 2, 0, 1, 1, 0}], 
   gli["CF230", {1, 1, 1, 0, 0, 0, 1, 1, 0}], 
   gli["CF230", {1, 1, 1, 0, 0, 0, 1, 2, 0}]}, 
 "Blocks" -> {{1}, {2}, {3}, {4, 5, 6, 7}, {8, 9}}, 
 "ClassIDs" -> {1, 2, 2, 49, 8}, "OriginalConnectionV" -> 
  {{-(((-1 + 2*eps)*(-1 + 2*t))/(1 - 2*t + t^2 - v + 2*t*v)), 0, 0, 0, 0, 0, 
    0, 0, 0}, {((-2 + 3*eps)*(-1 + t)^3)/(v*(1 - 2*t + t^2 + t*v)*
      (1 - 2*t + t^2 - v + 2*t*v)), -((eps*(1 - 2*t + t^2 + 2*t*v))/
      (v*(1 - 2*t + t^2 + t*v))), 0, 0, 0, 0, 0, 0, 0}, 
   {-(((-2 + 3*eps)*(-1 + t)*t)/((-1 + v)*(-1 + t + v)*
       (1 - 2*t + t^2 - v + 2*t*v))), 0, 
    -((eps*(-2 + t + 2*v))/((-1 + v)*(-1 + t + v))), 0, 0, 0, 0, 0, 0}, 
   {((-2 + 13*eps - 27*eps^2 + 18*eps^3)*(-1 + t)^3)/
     (eps^2*(1 - 2*t + t^2 - v)*v*(-1 + t + v)*(1 - 2*t + t^2 - v + 2*t*v)), 
    ((-1 + t)*(-4 + 20*eps - 24*eps^2 + 4*t - 20*eps*t + 24*eps^2*t - v + 
       5*eps*v - 6*eps^2*v))/(2*eps*(1 - 2*t + t^2 - v)*v*(-1 + t + v)), 
    -1/2*((-1 + t)*(-1 + 5*eps - 6*eps^2 + t - 5*eps*t + 6*eps^2*t - v + 
        5*eps*v - 6*eps^2*v))/(eps*(1 - 2*t + t^2 - v)*v*(-1 + t + v)), 
    (-5*eps + 15*eps*t - 15*eps*t^2 + 5*eps*t^3 + v + 5*eps*v - t*v - 
      15*eps*t*v + 10*eps*t^2*v - v^2)/(v*(-1 + t + v)*(-1 + 2*t - t^2 + v)), 
    (-2*(t - 2*t^2 + t^3 + t^2*v))/((1 - 2*t + t^2 - v)*v), 
    -((t*v)/(1 - 2*t + t^2 - v)), (t - t^2 + t*v)/(1 - 2*t + t^2 - v), 0, 0}, 
   {0, (-3*(-1 + t)^2*(-2 + 10*eps - 12*eps^2 + 6*t - 30*eps*t + 36*eps^2*t - 
       6*t^2 + 30*eps*t^2 - 36*eps^2*t^2 + 2*t^3 - 10*eps*t^3 + 
       12*eps^2*t^3 + 3*v - 15*eps*v + 18*eps^2*v - 6*t*v + 30*eps*t*v - 
       36*eps^2*t*v + 3*t^2*v - 15*eps*t^2*v + 18*eps^2*t^2*v - v^2 + 
       5*eps*v^2 - 6*eps^2*v^2 + 2*t*v^2 - 10*eps*t*v^2 + 12*eps^2*t*v^2))/
     (2*t*v*(-1 + t + v)^2*(1 - 2*t + t^2 + t*v)*(1 - 2*t + t^2 - v + 
       2*t*v)), 0, (3*(-1 + t)*(-2*eps^2 + 6*eps^2*t - 6*eps^2*t^2 + 
       2*eps^2*t^3 + 3*eps^2*v - 4*eps^2*t*v + eps^2*t^2*v - eps^2*v^2))/
     (t*v*(-1 + t + v)^2*(1 - 2*t + t^2 + t*v)), 
    (-2*eps + 10*eps*t - 20*eps*t^2 + 20*eps*t^3 - 10*eps*t^4 + 2*eps*t^5 - 
      v + 2*eps*v + 5*t*v - 8*eps*t*v - 9*t^2*v + 12*eps*t^2*v + 7*t^3*v - 
      8*eps*t^3*v - 2*t^4*v + 2*eps*t^4*v + v^2 - 7*t*v^2 - 2*eps*t*v^2 + 
      12*t^2*v^2 + 6*eps*t^2*v^2 - 6*t^3*v^2 - 4*eps*t^3*v^2 + 2*t*v^3 + 
      2*eps*t*v^3 - 4*t^2*v^3 - 4*eps*t^2*v^3)/(v*(-1 + t + v)*
      (1 - 2*t + t^2 + t*v)*(1 - 2*t + t^2 - v + 2*t*v)), 
    -((eps*(-1 + t)*v)/((-1 + t + v)*(1 - 2*t + t^2 + t*v))), 
    (2*(-1 + t)*(-eps + 3*eps*t - 3*eps*t^2 + eps*t^3 + 2*eps*v - 4*eps*t*v + 
       2*eps*t^2*v - eps*v^2 + 2*eps*t*v^2))/((-1 + t + v)*
      (1 - 2*t + t^2 + t*v)*(1 - 2*t + t^2 - v + 2*t*v)), 0, 0}, 
   {(-3*(-2 + 13*eps - 27*eps^2 + 18*eps^3)*(-1 + t)^4)/
     (2*eps*t*v^2*(-1 + t + v)*(1 - 2*t + t^2 + t*v)*
      (1 - 2*t + t^2 - v + 2*t*v)), (-3*(1 - 5*eps + 6*eps^2)*(-1 + t)^3)/
     (2*t*v^2*(-1 + t + v)*(1 - 2*t + t^2 + t*v)), 
    (3*(1 - 5*eps + 6*eps^2)*(-1 + t))/(2*t*v^2*(-1 + t + v)), 
    (3*(eps^2 - 2*eps^2*t + eps^2*t^2 - eps^2*v))/(t*v^2*(-1 + t + v)), 
    (2*eps*(-1 + t))/v^2, -(((1 + 2*eps)*(-1 + t + 2*v))/(v*(-1 + t + v))), 
    eps/v, 0, 0}, {(3*(-2 + 13*eps - 27*eps^2 + 18*eps^3)*(-1 + t)^2)/
     (2*eps*(-1 + v)*v*(-1 + t + v)^2*(1 - 2*t + t^2 - v + 2*t*v)), 
    (3*(1 - 5*eps + 6*eps^2)*(-1 + t)*(-1 + 2*t + v))/
     (2*t*(-1 + v)*v*(-1 + t + v)^2), (-3*(1 - 5*eps + 6*eps^2)*(-1 + t))/
     (2*(-1 + v)*v*(-1 + t + v)^2), 
    (-3*(eps^2 - 2*eps^2*t + eps^2*t^2 - eps^2*v))/(t*v*(-1 + t + v)^2), 
    (-2*eps*t*(1 - 2*t + t^2 + t*v))/((-1 + t)*(-1 + v)*v*(-1 + t + v)), 
    (eps*(-1 + 2*t + v))/((-1 + v)*(-1 + t + v)), 
    (-1 - 2*eps + t + 2*eps*t + 3*v + 6*eps*v - t*v - 4*eps*t*v - 2*v^2 - 
      4*eps*v^2)/((-1 + v)*v*(-1 + t + v)), 0, 0}, 
   {((-2 + 13*eps - 27*eps^2 + 18*eps^3)*(-1 + t)*t)/
     (2*eps^2*(-1 + v)*v*(-1 + t + v)*(1 - 2*t + t^2 - v + 2*t*v)), 
    -1/4*((1 - 5*eps + 6*eps^2)*(-4 + 3*t + 4*v))/(eps*(-1 + v)*v*
       (-1 + t + v)), 0, 0, 0, 0, 0, (-2 + 4*eps + 2*t - 4*eps*t + 4*v - 
      4*eps*v - 2*t*v + eps*t*v - 2*v^2)/(2*(-1 + v)*v*(-1 + t + v)), 
    -1/4*(t*(1 - 2*t + t^2 - v + 2*t*v))/((-1 + t)*(-1 + v)*v*(-1 + t + v))}, 
   {(3*(-2 + 13*eps - 27*eps^2 + 18*eps^3)*(-1 + t)^2*
      (-1 + 3*t - 3*t^2 + t^3 + 2*v - 4*t*v + 2*t^2*v - v^2 + 2*t*v^2))/
     (eps*(-1 + v)*v*(-1 + t + v)*(1 - 2*t + t^2 + t*v)*
      (1 - 2*t + t^2 - v + 2*t*v)^2), 
    (-3*(-1 + t)*(2 - 10*eps + 12*eps^2 - 6*t + 30*eps*t - 36*eps^2*t + 
       6*t^2 - 30*eps*t^2 + 36*eps^2*t^2 - 2*t^3 + 10*eps*t^3 - 
       12*eps^2*t^3 - 4*v + 20*eps*v - 24*eps^2*v + 9*t*v - 45*eps*t*v + 
       54*eps^2*t*v - 6*t^2*v + 30*eps*t^2*v - 36*eps^2*t^2*v + t^3*v - 
       5*eps*t^3*v + 6*eps^2*t^3*v + 2*v^2 - 10*eps*v^2 + 12*eps^2*v^2 - 
       4*t*v^2 + 20*eps*t*v^2 - 24*eps^2*t*v^2 + t^2*v^2 - 5*eps*t^2*v^2 + 
       6*eps^2*t^2*v^2))/(2*(-1 + v)*v*(-1 + t + v)*(1 - 2*t + t^2 + t*v)*
      (1 - 2*t + t^2 - v + 2*t*v)), 0, 0, 0, 0, 0, 
    (3*eps^2*(-1 + t)*t*v)/((-1 + v)*(-1 + t + v)*(1 - 2*t + t^2 - v + 
       2*t*v)), (4*eps - 12*eps*t + 12*eps*t^2 - 4*eps*t^3 + 2*v - 8*eps*v - 
      6*t*v + 17*eps*t*v + 4*t^2*v - 14*eps*t^2*v + 5*eps*t^3*v - 4*v^2 + 
      4*eps*v^2 + 10*t*v^2 - 5*eps*t*v^2 - 4*t^2*v^2 + 2*eps*t^2*v^2 + 
      2*v^3 - 4*t*v^3)/(2*(-1 + v)*v*(-1 + t + v)*(1 - 2*t + t^2 - v + 
       2*t*v))}}, "OriginalConnectionT" -> 
  {{-(((-1 + 2*eps)*(1 - 2*t + t^2 - v))/((-1 + t)*(1 - 2*t + t^2 - v + 
        2*t*v))), 0, 0, 0, 0, 0, 0, 0, 0}, 
   {-(((-2 + 3*eps)*(1 - 2*t + t^2 - v))/((1 - 2*t + t^2 + t*v)*
       (1 - 2*t + t^2 - v + 2*t*v))), -((eps*(1 - 2*t + t^2 - v))/
      ((-1 + t)*(1 - 2*t + t^2 + t*v))), 0, 0, 0, 0, 0, 0, 0}, 
   {((-2 + 3*eps)*(1 - 2*t + t^2 - v))/(t*(-1 + t + v)*
      (1 - 2*t + t^2 - v + 2*t*v)), 0, 
    -((eps*(1 - 2*t + t^2 - v))/((-1 + t)*t*(-1 + t + v))), 0, 0, 0, 0, 0, 
    0}, {-(((-1 + t)*(2 - 13*eps + 27*eps^2 - 18*eps^3 - 2*t^2 + 13*eps*t^2 - 
        27*eps^2*t^2 + 18*eps^3*t^2 - 2*v + 13*eps*v - 27*eps^2*v + 
        18*eps^3*v))/(eps^2*t*(1 - 2*t + t^2 - v)*(-1 + t + v)*
       (1 - 2*t + t^2 - v + 2*t*v))), (5 - 25*eps + 30*eps^2 - 2*t + 
      10*eps*t - 12*eps^2*t - 3*t^2 + 15*eps*t^2 - 18*eps^2*t^2 - 5*v + 
      25*eps*v - 30*eps^2*v + 2*t*v - 10*eps*t*v + 12*eps^2*t*v)/
     (2*eps*t*(1 - 2*t + t^2 - v)*(-1 + t + v)), 
    -(((-1 + t)*(-1 + 5*eps - 6*eps^2 + v - 5*eps*v + 6*eps^2*v))/
      (eps*t*(1 - 2*t + t^2 - v)*(-1 + t + v))), 
    (-5*eps + t + 10*eps*t - 3*t^2 + 3*t^3 - 10*eps*t^3 - t^4 + 5*eps*t^4 + 
      10*eps*v - 20*eps*t*v + t^2*v - t^3*v + 10*eps*t^3*v - 5*eps*v^2 - 
      t*v^2 + 10*eps*t*v^2)/((-1 + t)*t*(1 - 2*t + t^2 - v)*(-1 + t + v)), 
    (2*(-1 + 2*t - 2*t^3 + t^4 + v - 3*t*v + t^2*v + t^3*v + t*v^2))/
     ((-1 + t)^2*(1 - 2*t + t^2 - v)), (v - 2*t*v + t^2*v - v^2 + 2*t*v^2)/
     ((-1 + t)*(1 - 2*t + t^2 - v)), (-2*(-v + v^2))/(1 - 2*t + t^2 - v), 0, 
    0}, {0, (3*(-1 + t)*(1 - 2*t + t^2 - v)*(-1 + 5*eps - 6*eps^2 + t^2 - 
       5*eps*t^2 + 6*eps^2*t^2 + v - 5*eps*v + 6*eps^2*v))/
     (2*t^2*(-1 + t + v)^2*(1 - 2*t + t^2 + t*v)*(1 - 2*t + t^2 - v + 
       2*t*v)), 0, (-3*(1 - 2*t + t^2 - v)*(-eps^2 - 2*eps^2*t + 
       3*eps^2*t^2 + eps^2*v + 2*eps^2*t*v))/(t^2*(-1 + t + v)^2*
      (1 - 2*t + t^2 + t*v)), 
    -(((1 - 2*t + t^2 - v)*(1 - 5*t - 4*eps*t + 9*t^2 + 12*eps*t^2 - 7*t^3 - 
        12*eps*t^3 + 2*t^4 + 4*eps*t^4 - v + 7*t*v + 6*eps*t*v - 12*t^2*v - 
        16*eps*t^2*v + 6*t^3*v + 10*eps*t^3*v - 2*t*v^2 - 2*eps*t*v^2 + 
        4*t^2*v^2 + 6*eps*t^2*v^2))/((-1 + t)*t*(-1 + t + v)*
       (1 - 2*t + t^2 + t*v)*(1 - 2*t + t^2 - v + 2*t*v))), 
    -((eps*(1 - 2*t + t^2 - v)*v)/(t*(-1 + t + v)*(1 - 2*t + t^2 + t*v))), 
    (2*(-1 + t)*(1 - 2*t + t^2 - v)*(-(eps*v) + eps*v^2))/
     (t*(-1 + t + v)*(1 - 2*t + t^2 + t*v)*(1 - 2*t + t^2 - v + 2*t*v)), 0, 
    0}, {(3*(-2 + 13*eps - 27*eps^2 + 18*eps^3)*(-1 + t)*(1 - 2*t + t^2 - v))/
     (2*eps*t*v*(-1 + t + v)*(1 - 2*t + t^2 + t*v)*(1 - 2*t + t^2 - v + 
       2*t*v)), (3*(1 - 5*eps + 6*eps^2)*(1 - 2*t + t^2 - v))/
     (2*t*v*(-1 + t + v)*(1 - 2*t + t^2 + t*v)), 0, 
    (-6*eps^2*(1 - 2*t + t^2 - v))/((-1 + t)*t*v*(-1 + t + v)), 
    (-2*eps*(1 - 2*t + t^2 - v))/((-1 + t)^2*v), 
    -(((1 + 2*eps)*(1 - 2*t + t^2 - v))/((-1 + t)*t*(-1 + t + v))), 0, 0, 0}, 
   {(-3*(-2 + 13*eps - 27*eps^2 + 18*eps^3)*(-1 + t)*(1 - 2*t + t^2 - v))/
     (2*eps*t^2*v*(-1 + t + v)^2*(1 - 2*t + t^2 - v + 2*t*v)), 
    (-3*(1 - 5*eps + 6*eps^2)*(1 - 2*t + t^2 - v))/(2*t^2*v*(-1 + t + v)^2), 
    (3*(1 - 5*eps + 6*eps^2)*(1 - 2*t + t^2 - v))/(2*t^2*v*(-1 + t + v)^2), 
    (3*(1 - 2*t + t^2 - v)*(eps^2 - 2*eps^2*t + eps^2*t^2 - eps^2*v + 
       2*eps^2*t*v))/((-1 + t)*t^2*v*(-1 + t + v)^2), 
    (2*eps*(1 - 2*t + t^2 - v)*(1 - 2*t + t^2 + t*v))/
     ((-1 + t)^2*t*v*(-1 + t + v)), -((eps*(1 - 2*t + t^2 - v))/
      ((-1 + t)*t*(-1 + t + v))), (-1 + 2*t - t^2 + v)/
     ((-1 + t)*t*(-1 + t + v)), 0, 0}, 
   {-1/2*((-2 + 13*eps - 27*eps^2 + 18*eps^3)*(1 - 2*t + t^2 - v))/
      (eps^2*t*v*(-1 + t + v)*(1 - 2*t + t^2 - v + 2*t*v)), 
    -1/4*((1 - 5*eps + 6*eps^2)*(1 - 2*t + t^2 - v))/
      (eps*(-1 + t)*t*v*(-1 + t + v)), 0, 0, 0, 0, 0, 
    -1/2*(eps*(1 - 2*t + t^2 - v))/((-1 + t)*t*(-1 + t + v)), 
    ((1 - 2*t + t^2 - v)*(1 - 2*t + t^2 - v + 2*t*v))/
     (4*(-1 + t)^2*t*v*(-1 + t + v))}, 
   {(3*(-2 + 13*eps - 27*eps^2 + 18*eps^3)*(-1 + t)^2*(1 - 2*t + t^2 - v))/
     (eps*t*(-1 + t + v)*(1 - 2*t + t^2 + t*v)*(1 - 2*t + t^2 - v + 2*t*v)^
       2), (3*(1 - 2*t + t^2 - v)*(-1 + 5*eps - 6*eps^2 + t^2 - 5*eps*t^2 + 
       6*eps^2*t^2 + t*v - 5*eps*t*v + 6*eps^2*t*v))/
     (2*t*(-1 + t + v)*(1 - 2*t + t^2 + t*v)*(1 - 2*t + t^2 - v + 2*t*v)), 0, 
    0, 0, 0, 0, (-3*eps^2*(1 - 2*t + t^2 - v)*v)/
     (t*(-1 + t + v)*(1 - 2*t + t^2 - v + 2*t*v)), 
    -1/2*((1 - 2*t + t^2 - v)*(-3*eps - 2*t - 2*eps*t + 2*t^2 + 5*eps*t^2 + 
        3*eps*v + 2*t*v + 2*eps*t*v))/((-1 + t)*t*(-1 + t + v)*
       (1 - 2*t + t^2 - v + 2*t*v))}}, "Transformation" -> 
  {{(1 - 2*t + t^2 - v + 2*t*v)/(-1 + t), 0, 0, 0, 0, 0, 0, 0, 0}, 
   {0, 1, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 1, 0, 0, 0, 0, 0, 0}, 
   {0, 0, 0, (-1 + t)/(1 - 2*t + t^2 - v), 0, 0, 0, 0, 0}, 
   {0, 0, 0, 0, (eps*(-1 + t)^2)/(t*(-1 + t + v)*(1 - 2*t + t^2 + t*v)), 0, 
    0, 0, 0}, {0, 0, 0, 0, 0, (eps*(-1 + t))/(t*v*(-1 + t + v)), 0, 0, 0}, 
   {0, 0, 0, 0, 0, 0, (eps*(-1 + t))/(t*v*(-1 + t + v)), 0, 0}, 
   {0, 0, 0, 0, 0, 0, 0, v^(-1), 0}, {0, 0, 0, 0, 0, 0, 0, 0, 
    (eps*(-1 + t))/(1 - 2*t + t^2 - v + 2*t*v)}}, 
 "InverseTransformation" -> {{(-1 + t)/(1 - 2*t + t^2 - v + 2*t*v), 0, 0, 0, 
    0, 0, 0, 0, 0}, {0, 1, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 1, 0, 0, 0, 0, 0, 0}, 
   {0, 0, 0, (1 - 2*t + t^2 - v)/(-1 + t), 0, 0, 0, 0, 0}, 
   {0, 0, 0, 0, (t*(-1 + t + v)*(1 - 2*t + t^2 + t*v))/(eps*(-1 + t)^2), 0, 
    0, 0, 0}, {0, 0, 0, 0, 0, (t*v*(-1 + t + v))/(eps*(-1 + t)), 0, 0, 0}, 
   {0, 0, 0, 0, 0, 0, (t*v*(-1 + t + v))/(eps*(-1 + t)), 0, 0}, 
   {0, 0, 0, 0, 0, 0, 0, v, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 
    (1 - 2*t + t^2 - v + 2*t*v)/(eps*(-1 + t))}}, 
 "TransformedConnectionV" -> 
  {{(-2*(-eps + 2*eps*t))/(1 - 2*t + t^2 - v + 2*t*v), 0, 0, 0, 0, 0, 0, 0, 
    0}, {((-2 + 3*eps)*(-1 + t)^2)/(v*(1 - 2*t + t^2 + t*v)), 
    -((eps*(1 - 2*t + t^2 + 2*t*v))/(v*(1 - 2*t + t^2 + t*v))), 0, 0, 0, 0, 
    0, 0, 0}, {-(((-2 + 3*eps)*t)/((-1 + v)*(-1 + t + v))), 0, 
    -((eps*(-2 + t + 2*v))/((-1 + v)*(-1 + t + v))), 0, 0, 0, 0, 0, 0}, 
   {((-2 + 13*eps - 27*eps^2 + 18*eps^3)*(-1 + t))/(eps^2*v*(-1 + t + v)), 
    (-4 + 20*eps - 24*eps^2 + 4*t - 20*eps*t + 24*eps^2*t - v + 5*eps*v - 
      6*eps^2*v)/(2*eps*v*(-1 + t + v)), 
    (1 - 5*eps + 6*eps^2 - t + 5*eps*t - 6*eps^2*t + v - 5*eps*v + 6*eps^2*v)/
     (2*eps*v*(-1 + t + v)), (-5*(-eps + 3*eps*t - 3*eps*t^2 + eps*t^3 + 
       eps*v - 3*eps*t*v + 2*eps*t^2*v))/((1 - 2*t + t^2 - v)*v*
      (-1 + t + v)), (-2*eps*(-1 + t))/(v*(-1 + t + v)), -(eps/(-1 + t + v)), 
    -((eps*(-1 + t - v))/(v*(-1 + t + v))), 0, 0}, 
   {0, (-3*(-2 + 10*eps - 12*eps^2 + 6*t - 30*eps*t + 36*eps^2*t - 6*t^2 + 
       30*eps*t^2 - 36*eps^2*t^2 + 2*t^3 - 10*eps*t^3 + 12*eps^2*t^3 + 3*v - 
       15*eps*v + 18*eps^2*v - 6*t*v + 30*eps*t*v - 36*eps^2*t*v + 3*t^2*v - 
       15*eps*t^2*v + 18*eps^2*t^2*v - v^2 + 5*eps*v^2 - 6*eps^2*v^2 + 
       2*t*v^2 - 10*eps*t*v^2 + 12*eps^2*t*v^2))/(2*eps*v*(-1 + t + v)*
      (1 - 2*t + t^2 - v + 2*t*v)), 0, (3*eps*(-2 + 2*t + v))/
     (v*(-1 + t + v)), (-2*(-eps + 4*eps*t - 6*eps*t^2 + 4*eps*t^3 - 
       eps*t^4 - eps*t*v^2 + 2*eps*t^2*v^2))/(v*(1 - 2*t + t^2 + t*v)*
      (1 - 2*t + t^2 - v + 2*t*v)), -(eps/(-1 + t + v)), 
    (2*(-eps + 3*eps*t - 3*eps*t^2 + eps*t^3 + 2*eps*v - 4*eps*t*v + 
       2*eps*t^2*v - eps*v^2 + 2*eps*t*v^2))/(v*(-1 + t + v)*
      (1 - 2*t + t^2 - v + 2*t*v)), 0, 0}, 
   {(-3*(-2 + 13*eps - 27*eps^2 + 18*eps^3)*(-1 + t)^2)/
     (2*eps^2*v*(1 - 2*t + t^2 + t*v)), (-3*(1 - 5*eps + 6*eps^2)*(-1 + t)^2)/
     (2*eps*v*(1 - 2*t + t^2 + t*v)), (3*(1 - 5*eps + 6*eps^2))/(2*eps*v), 
    (3*eps)/v, (2*eps*(-1 + t)^2)/(v*(1 - 2*t + t^2 + t*v)), 
    (-2*eps*(-1 + t + 2*v))/(v*(-1 + t + v)), eps/v, 0, 0}, 
   {(3*(-2 + 13*eps - 27*eps^2 + 18*eps^3)*t)/(2*eps^2*(-1 + v)*
      (-1 + t + v)), (3*(1 - 5*eps + 6*eps^2)*(-1 + 2*t + v))/
     (2*eps*(-1 + v)*(-1 + t + v)), (-3*(1 - 5*eps + 6*eps^2)*t)/
     (2*eps*(-1 + v)*(-1 + t + v)), (-3*eps)/(-1 + t + v), 
    (-2*eps*t)/((-1 + v)*(-1 + t + v)), (eps*(-1 + 2*t + v))/
     ((-1 + v)*(-1 + t + v)), (-2*(-eps + 2*eps*v))/((-1 + v)*v), 0, 0}, 
   {((-2 + 13*eps - 27*eps^2 + 18*eps^3)*t)/(2*eps^2*(-1 + v)*(-1 + t + v)), 
    -1/4*((1 - 5*eps + 6*eps^2)*(-4 + 3*t + 4*v))/
      (eps*(-1 + v)*(-1 + t + v)), 0, 0, 0, 0, 0, 
    (4*eps - 4*eps*t - 4*eps*v + eps*t*v)/(2*(-1 + v)*v*(-1 + t + v)), 
    -1/4*(eps*t)/((-1 + v)*(-1 + t + v))}, 
   {(3*(-2 + 13*eps - 27*eps^2 + 18*eps^3)*(-1 + 3*t - 3*t^2 + t^3 + 2*v - 
       4*t*v + 2*t^2*v - v^2 + 2*t*v^2))/(eps^2*(-1 + v)*v*(-1 + t + v)*
      (1 - 2*t + t^2 + t*v)), (-3*(2 - 10*eps + 12*eps^2 - 6*t + 30*eps*t - 
       36*eps^2*t + 6*t^2 - 30*eps*t^2 + 36*eps^2*t^2 - 2*t^3 + 10*eps*t^3 - 
       12*eps^2*t^3 - 4*v + 20*eps*v - 24*eps^2*v + 9*t*v - 45*eps*t*v + 
       54*eps^2*t*v - 6*t^2*v + 30*eps*t^2*v - 36*eps^2*t^2*v + t^3*v - 
       5*eps*t^3*v + 6*eps^2*t^3*v + 2*v^2 - 10*eps*v^2 + 12*eps^2*v^2 - 
       4*t*v^2 + 20*eps*t*v^2 - 24*eps^2*t*v^2 + t^2*v^2 - 5*eps*t^2*v^2 + 
       6*eps^2*t^2*v^2))/(2*eps*(-1 + v)*v*(-1 + t + v)*
      (1 - 2*t + t^2 + t*v)), 0, 0, 0, 0, 0, 
    (3*eps*t)/((-1 + v)*(-1 + t + v)), (4*eps - 12*eps*t + 12*eps*t^2 - 
      4*eps*t^3 - 8*eps*v + 17*eps*t*v - 14*eps*t^2*v + 5*eps*t^3*v + 
      4*eps*v^2 - 5*eps*t*v^2 + 2*eps*t^2*v^2)/(2*(-1 + v)*v*(-1 + t + v)*
      (1 - 2*t + t^2 - v + 2*t*v))}}, "TransformedConnectionT" -> 
  {{(-2*eps*(1 - 2*t + t^2 - v))/((-1 + t)*(1 - 2*t + t^2 - v + 2*t*v)), 0, 
    0, 0, 0, 0, 0, 0, 0}, {-(((-2 + 3*eps)*(1 - 2*t + t^2 - v))/
      ((-1 + t)*(1 - 2*t + t^2 + t*v))), 
    -((eps*(1 - 2*t + t^2 - v))/((-1 + t)*(1 - 2*t + t^2 + t*v))), 0, 0, 0, 
    0, 0, 0, 0}, {((-2 + 3*eps)*(1 - 2*t + t^2 - v))/
     ((-1 + t)*t*(-1 + t + v)), 0, -((eps*(1 - 2*t + t^2 - v))/
      ((-1 + t)*t*(-1 + t + v))), 0, 0, 0, 0, 0, 0}, 
   {(-2 + 13*eps - 27*eps^2 + 18*eps^3 + 2*t^2 - 13*eps*t^2 + 27*eps^2*t^2 - 
      18*eps^3*t^2 + 2*v - 13*eps*v + 27*eps^2*v - 18*eps^3*v)/
     (eps^2*(-1 + t)*t*(-1 + t + v)), (5 - 25*eps + 30*eps^2 - 2*t + 
      10*eps*t - 12*eps^2*t - 3*t^2 + 15*eps*t^2 - 18*eps^2*t^2 - 5*v + 
      25*eps*v - 30*eps^2*v + 2*t*v - 10*eps*t*v + 12*eps^2*t*v)/
     (2*eps*(-1 + t)*t*(-1 + t + v)), (1 - 5*eps + 6*eps^2 - v + 5*eps*v - 
      6*eps^2*v)/(eps*t*(-1 + t + v)), 
    (5*(-eps + 2*eps*t - 2*eps*t^3 + eps*t^4 + 2*eps*v - 4*eps*t*v + 
       2*eps*t^3*v - eps*v^2 + 2*eps*t*v^2))/((-1 + t)*t*(1 - 2*t + t^2 - v)*
      (-1 + t + v)), (2*eps*(-1 + t^2 + v))/((-1 + t)*t*(-1 + t + v)), 
    (eps*(1 - 2*t + t^2 - v + 2*t*v))/((-1 + t)*t*(-1 + t + v)), 
    (-2*eps*(-1 + v))/(t*(-1 + t + v)), 0, 0}, 
   {0, (3*(1 - 2*t + t^2 - v)*(-1 + 5*eps - 6*eps^2 + t^2 - 5*eps*t^2 + 
       6*eps^2*t^2 + v - 5*eps*v + 6*eps^2*v))/(2*eps*(-1 + t)*t*(-1 + t + v)*
      (1 - 2*t + t^2 - v + 2*t*v)), 0, 
    (-3*eps*(-1 - 2*t + 3*t^2 + v + 2*t*v))/((-1 + t)*t*(-1 + t + v)), 
    (-2*(2*eps - 8*eps*t + 12*eps*t^2 - 8*eps*t^3 + 2*eps*t^4 - 3*eps*v + 
       9*eps*t*v - 9*eps*t^2*v + 3*eps*t^3*v + eps*v^2 - 3*eps*t*v^2))/
     ((-1 + t)*(1 - 2*t + t^2 + t*v)*(1 - 2*t + t^2 - v + 2*t*v)), 
    -((eps*(1 - 2*t + t^2 - v))/((-1 + t)*t*(-1 + t + v))), 
    (2*(1 - 2*t + t^2 - v)*(-eps + eps*v))/(t*(-1 + t + v)*
      (1 - 2*t + t^2 - v + 2*t*v)), 0, 0}, 
   {(3*(-2 + 13*eps - 27*eps^2 + 18*eps^3)*(1 - 2*t + t^2 - v))/
     (2*eps^2*(-1 + t)*(1 - 2*t + t^2 + t*v)), 
    (3*(1 - 5*eps + 6*eps^2)*(1 - 2*t + t^2 - v))/
     (2*eps*(-1 + t)*(1 - 2*t + t^2 + t*v)), 0, (-6*eps)/(-1 + t), 
    (-2*eps*(1 - 2*t + t^2 - v))/((-1 + t)*(1 - 2*t + t^2 + t*v)), 
    (-2*eps*(1 - 2*t + t^2 - v))/((-1 + t)*t*(-1 + t + v)), 0, 0, 0}, 
   {(-3*(-2 + 13*eps - 27*eps^2 + 18*eps^3)*(1 - 2*t + t^2 - v))/
     (2*eps^2*(-1 + t)*t*(-1 + t + v)), 
    (-3*(1 - 5*eps + 6*eps^2)*(1 - 2*t + t^2 - v))/
     (2*eps*(-1 + t)*t*(-1 + t + v)), 
    (3*(1 - 5*eps + 6*eps^2)*(1 - 2*t + t^2 - v))/
     (2*eps*(-1 + t)*t*(-1 + t + v)), (3*eps*(1 - 2*t + t^2 - v + 2*t*v))/
     ((-1 + t)*t*(-1 + t + v)), (2*eps*(1 - 2*t + t^2 - v))/
     ((-1 + t)*t*(-1 + t + v)), -((eps*(1 - 2*t + t^2 - v))/
      ((-1 + t)*t*(-1 + t + v))), 0, 0, 0}, 
   {-1/2*((-2 + 13*eps - 27*eps^2 + 18*eps^3)*(1 - 2*t + t^2 - v))/
      (eps^2*(-1 + t)*t*(-1 + t + v)), 
    -1/4*((1 - 5*eps + 6*eps^2)*(1 - 2*t + t^2 - v))/
      (eps*(-1 + t)*t*(-1 + t + v)), 0, 0, 0, 0, 0, 
    -1/2*(eps*(1 - 2*t + t^2 - v))/((-1 + t)*t*(-1 + t + v)), 
    (eps*(1 - 2*t + t^2 - v))/(4*(-1 + t)*t*(-1 + t + v))}, 
   {(3*(-2 + 13*eps - 27*eps^2 + 18*eps^3)*(1 - 2*t + t^2 - v))/
     (eps^2*t*(-1 + t + v)*(1 - 2*t + t^2 + t*v)), 
    (3*(1 - 2*t + t^2 - v)*(-1 + 5*eps - 6*eps^2 + t^2 - 5*eps*t^2 + 
       6*eps^2*t^2 + t*v - 5*eps*t*v + 6*eps^2*t*v))/
     (2*eps*(-1 + t)*t*(-1 + t + v)*(1 - 2*t + t^2 + t*v)), 0, 0, 0, 0, 0, 
    (-3*eps*(1 - 2*t + t^2 - v))/((-1 + t)*t*(-1 + t + v)), 
    -1/2*((1 - 2*t + t^2 - v)*(-3*eps - 2*eps*t + 5*eps*t^2 + 3*eps*v + 
        2*eps*t*v))/((-1 + t)*t*(-1 + t + v)*(1 - 2*t + t^2 - v + 2*t*v))}}, 
 "RadialPath" -> {v -> tau*vFinal, t -> tau*tFinal}, 
 "RadialPathConnection" -> 
  {{(-2*(eps*tFinal - 2*eps*tau*tFinal^2 + eps*tau^2*tFinal^3 + eps*vFinal - 
       4*eps*tau*tFinal*vFinal + 2*eps*tau^2*tFinal^2*vFinal))/
     ((-1 + tau*tFinal)*(1 - 2*tau*tFinal + tau^2*tFinal^2 - tau*vFinal + 
       2*tau^2*tFinal*vFinal)), 0, 0, 0, 0, 0, 0, 0, 0}, 
   {-(((-2 + 3*eps)*(1 - 2*tau*tFinal + tau^2*tFinal^2 - 
        tau^2*tFinal*vFinal))/(tau*(-1 + tau*tFinal)*(1 - 2*tau*tFinal + 
        tau^2*tFinal^2 + tau^2*tFinal*vFinal))), 
    -((eps*(-1 + 4*tau*tFinal - 5*tau^2*tFinal^2 + 2*tau^3*tFinal^3 - 
        3*tau^2*tFinal*vFinal + 2*tau^3*tFinal^2*vFinal))/
      (tau*(-1 + tau*tFinal)*(1 - 2*tau*tFinal + tau^2*tFinal^2 + 
        tau^2*tFinal*vFinal))), 0, 0, 0, 0, 0, 0, 0}, 
   {-(((-2 + 3*eps)*(1 - 2*tau*tFinal + tau^2*tFinal^2 - 2*tau*vFinal + 
        tau^2*tFinal*vFinal + tau^2*vFinal^2))/(tau*(-1 + tau*tFinal)*
       (-1 + tau*vFinal)*(-1 + tau*tFinal + tau*vFinal))), 0, 
    -((eps*(-1 + 2*tau*tFinal - tau^2*tFinal^2 + 4*tau*vFinal - 
        5*tau^2*tFinal*vFinal + 2*tau^3*tFinal^2*vFinal - 3*tau^2*vFinal^2 + 
        2*tau^3*tFinal*vFinal^2))/(tau*(-1 + tau*tFinal)*(-1 + tau*vFinal)*
       (-1 + tau*tFinal + tau*vFinal))), 0, 0, 0, 0, 0, 0}, 
   {(-4 + 26*eps - 54*eps^2 + 36*eps^3 + 4*tau*tFinal - 26*eps*tau*tFinal + 
      54*eps^2*tau*tFinal - 36*eps^3*tau*tFinal + 2*tau*vFinal - 
      13*eps*tau*vFinal + 27*eps^2*tau*vFinal - 18*eps^3*tau*vFinal)/
     (eps^2*tau*(-1 + tau*tFinal)*(-1 + tau*tFinal + tau*vFinal)), 
    (9 - 45*eps + 54*eps^2 - 10*tau*tFinal + 50*eps*tau*tFinal - 
      60*eps^2*tau*tFinal + tau^2*tFinal^2 - 5*eps*tau^2*tFinal^2 + 
      6*eps^2*tau^2*tFinal^2 - 4*tau*vFinal + 20*eps*tau*vFinal - 
      24*eps^2*tau*vFinal + tau^2*tFinal*vFinal - 5*eps*tau^2*tFinal*vFinal + 
      6*eps^2*tau^2*tFinal*vFinal)/(2*eps*tau*(-1 + tau*tFinal)*
      (-1 + tau*tFinal + tau*vFinal)), (3 - 15*eps + 18*eps^2 - tau*tFinal + 
      5*eps*tau*tFinal - 6*eps^2*tau*tFinal - tau*vFinal + 5*eps*tau*vFinal - 
      6*eps^2*tau*vFinal)/(2*eps*tau*(-1 + tau*tFinal + tau*vFinal)), 
    (5*(-2*eps + 6*eps*tau*tFinal - 6*eps*tau^2*tFinal^2 + 
       2*eps*tau^3*tFinal^3 + 3*eps*tau*vFinal - 8*eps*tau^2*tFinal*vFinal + 
       5*eps*tau^3*tFinal^2*vFinal - eps*tau^2*vFinal^2 + 
       2*eps*tau^3*tFinal*vFinal^2))/(tau*(-1 + tau*tFinal)*
      (1 - 2*tau*tFinal + tau^2*tFinal^2 - tau*vFinal)*
      (-1 + tau*tFinal + tau*vFinal)), 
    (2*eps*(-2 + 2*tau*tFinal + tau*vFinal))/(tau*(-1 + tau*tFinal)*
      (-1 + tau*tFinal + tau*vFinal)), 
    (eps*(1 - 2*tau*tFinal + tau^2*tFinal^2 + tau^2*tFinal*vFinal))/
     (tau*(-1 + tau*tFinal)*(-1 + tau*tFinal + tau*vFinal)), 
    (3*eps - eps*tau*tFinal - eps*tau*vFinal)/
     (tau*(-1 + tau*tFinal + tau*vFinal)), 0, 0}, 
   {0, (-3*(3 - 15*eps + 18*eps^2 - 10*tau*tFinal + 50*eps*tau*tFinal - 
       60*eps^2*tau*tFinal + 12*tau^2*tFinal^2 - 60*eps*tau^2*tFinal^2 + 
       72*eps^2*tau^2*tFinal^2 - 6*tau^3*tFinal^3 + 30*eps*tau^3*tFinal^3 - 
       36*eps^2*tau^3*tFinal^3 + tau^4*tFinal^4 - 5*eps*tau^4*tFinal^4 + 
       6*eps^2*tau^4*tFinal^4 - 5*tau*vFinal + 25*eps*tau*vFinal - 
       30*eps^2*tau*vFinal + 11*tau^2*tFinal*vFinal - 
       55*eps*tau^2*tFinal*vFinal + 66*eps^2*tau^2*tFinal*vFinal - 
       9*tau^3*tFinal^2*vFinal + 45*eps*tau^3*tFinal^2*vFinal - 
       54*eps^2*tau^3*tFinal^2*vFinal + 3*tau^4*tFinal^3*vFinal - 
       15*eps*tau^4*tFinal^3*vFinal + 18*eps^2*tau^4*tFinal^3*vFinal + 
       2*tau^2*vFinal^2 - 10*eps*tau^2*vFinal^2 + 12*eps^2*tau^2*vFinal^2 - 
       3*tau^3*tFinal*vFinal^2 + 15*eps*tau^3*tFinal*vFinal^2 - 
       18*eps^2*tau^3*tFinal*vFinal^2 + 2*tau^4*tFinal^2*vFinal^2 - 
       10*eps*tau^4*tFinal^2*vFinal^2 + 12*eps^2*tau^4*tFinal^2*vFinal^2))/
     (2*eps*tau*(-1 + tau*tFinal)*(-1 + tau*tFinal + tau*vFinal)*
      (1 - 2*tau*tFinal + tau^2*tFinal^2 - tau*vFinal + 
       2*tau^2*tFinal*vFinal)), 0, 
    (-3*eps*(-3 + 2*tau*tFinal + tau^2*tFinal^2 + 2*tau*vFinal + 
       tau^2*tFinal*vFinal))/(tau*(-1 + tau*tFinal)*(-1 + tau*tFinal + 
       tau*vFinal)), (-2*(eps - 3*eps*tau*tFinal + 2*eps*tau^2*tFinal^2 + 
       2*eps*tau^3*tFinal^3 - 3*eps*tau^4*tFinal^4 + eps*tau^5*tFinal^5 - 
       3*eps*tau^2*tFinal*vFinal + 9*eps*tau^3*tFinal^2*vFinal - 
       9*eps*tau^4*tFinal^3*vFinal + 3*eps*tau^5*tFinal^4*vFinal + 
       2*eps*tau^3*tFinal*vFinal^2 - 6*eps*tau^4*tFinal^2*vFinal^2 + 
       2*eps*tau^5*tFinal^3*vFinal^2))/(tau*(-1 + tau*tFinal)*
      (1 - 2*tau*tFinal + tau^2*tFinal^2 + tau^2*tFinal*vFinal)*
      (1 - 2*tau*tFinal + tau^2*tFinal^2 - tau*vFinal + 
       2*tau^2*tFinal*vFinal)), 
    -((eps*(1 - 2*tau*tFinal + tau^2*tFinal^2 - 2*tau*vFinal + 
        tau^2*tFinal*vFinal))/(tau*(-1 + tau*tFinal)*(-1 + tau*tFinal + 
        tau*vFinal))), (2*(-2*eps + 5*eps*tau*tFinal - 4*eps*tau^2*tFinal^2 + 
       eps*tau^3*tFinal^3 + 4*eps*tau*vFinal - 6*eps*tau^2*tFinal*vFinal + 
       3*eps*tau^3*tFinal^2*vFinal - 2*eps*tau^2*vFinal^2 + 
       2*eps*tau^3*tFinal*vFinal^2))/(tau*(-1 + tau*tFinal + tau*vFinal)*
      (1 - 2*tau*tFinal + tau^2*tFinal^2 - tau*vFinal + 
       2*tau^2*tFinal*vFinal)), 0, 0}, 
   {(3*(-2 + 13*eps - 27*eps^2 + 18*eps^3)*(1 - 2*tau*tFinal + 
       tau^2*tFinal^2 - tau^2*tFinal*vFinal))/(2*eps^2*tau*(-1 + tau*tFinal)*
      (1 - 2*tau*tFinal + tau^2*tFinal^2 + tau^2*tFinal*vFinal)), 
    (3*(1 - 5*eps + 6*eps^2)*(1 - 2*tau*tFinal + tau^2*tFinal^2 - 
       tau^2*tFinal*vFinal))/(2*eps*tau*(-1 + tau*tFinal)*
      (1 - 2*tau*tFinal + tau^2*tFinal^2 + tau^2*tFinal*vFinal)), 
    (3*(1 - 5*eps + 6*eps^2))/(2*eps*tau), (-3*eps*(1 + tau*tFinal))/
     (tau*(-1 + tau*tFinal)), (-2*eps*(1 - 2*tau*tFinal + tau^2*tFinal^2 - 
       tau^2*tFinal*vFinal))/(tau*(-1 + tau*tFinal)*(1 - 2*tau*tFinal + 
       tau^2*tFinal^2 + tau^2*tFinal*vFinal)), 
    (-2*eps*(2 - 4*tau*tFinal + 2*tau^2*tFinal^2 - 3*tau*vFinal + 
       2*tau^2*tFinal*vFinal))/(tau*(-1 + tau*tFinal)*
      (-1 + tau*tFinal + tau*vFinal)), eps/tau, 0, 0}, 
   {(3*(-2 + 13*eps - 27*eps^2 + 18*eps^3)*(1 - 2*tau*tFinal + 
       tau^2*tFinal^2 - 2*tau*vFinal + tau^2*tFinal*vFinal + tau^2*vFinal^2))/
     (2*eps^2*tau*(-1 + tau*tFinal)*(-1 + tau*vFinal)*
      (-1 + tau*tFinal + tau*vFinal)), 
    (3*(1 - 5*eps + 6*eps^2)*(1 - 2*tau*tFinal + tau^2*tFinal^2 - 
       tau*vFinal - tau^2*tFinal*vFinal + tau^3*tFinal^2*vFinal + 
       tau^3*tFinal*vFinal^2))/(2*eps*tau*(-1 + tau*tFinal)*(-1 + tau*vFinal)*
      (-1 + tau*tFinal + tau*vFinal)), 
    (-3*(1 - 5*eps + 6*eps^2)*(1 - 2*tau*tFinal + tau^2*tFinal^2 - 
       2*tau*vFinal + tau^2*tFinal*vFinal + tau^2*vFinal^2))/
     (2*eps*tau*(-1 + tau*tFinal)*(-1 + tau*vFinal)*(-1 + tau*tFinal + 
       tau*vFinal)), (3*eps*(1 - 2*tau*tFinal + tau^2*tFinal^2 + 
       tau^2*tFinal*vFinal))/(tau*(-1 + tau*tFinal)*(-1 + tau*tFinal + 
       tau*vFinal)), (-2*eps*(1 - 2*tau*tFinal + tau^2*tFinal^2 - 
       2*tau*vFinal + tau^2*tFinal*vFinal + tau^2*vFinal^2))/
     (tau*(-1 + tau*tFinal)*(-1 + tau*vFinal)*(-1 + tau*tFinal + 
       tau*vFinal)), (eps*(1 - 2*tau*tFinal + tau^2*tFinal^2 - tau*vFinal - 
       tau^2*tFinal*vFinal + tau^3*tFinal^2*vFinal + tau^3*tFinal*vFinal^2))/
     (tau*(-1 + tau*tFinal)*(-1 + tau*vFinal)*(-1 + tau*tFinal + 
       tau*vFinal)), (-2*(-eps + 2*eps*tau*vFinal))/(tau*(-1 + tau*vFinal)), 
    0, 0}, {((-2 + 13*eps - 27*eps^2 + 18*eps^3)*(1 - 2*tau*tFinal + 
       tau^2*tFinal^2 - 2*tau*vFinal + tau^2*tFinal*vFinal + tau^2*vFinal^2))/
     (2*eps^2*tau*(-1 + tau*tFinal)*(-1 + tau*vFinal)*
      (-1 + tau*tFinal + tau*vFinal)), 
    -1/4*((1 - 5*eps + 6*eps^2)*(-1 + 2*tau*tFinal - tau^2*tFinal^2 + 
        6*tau*vFinal - 9*tau^2*tFinal*vFinal + 4*tau^3*tFinal^2*vFinal - 
        5*tau^2*vFinal^2 + 4*tau^3*tFinal*vFinal^2))/
      (eps*tau*(-1 + tau*tFinal)*(-1 + tau*vFinal)*(-1 + tau*tFinal + 
        tau*vFinal)), 0, 0, 0, 0, 0, (-3*eps + 6*eps*tau*tFinal - 
      3*eps*tau^2*tFinal^2 + 2*eps*tau*vFinal - 3*eps*tau^2*tFinal*vFinal + 
      eps*tau^2*vFinal^2)/(2*tau*(-1 + tau*tFinal)*(-1 + tau*vFinal)*
      (-1 + tau*tFinal + tau*vFinal)), 
    -1/4*(eps*(1 - 2*tau*tFinal + tau^2*tFinal^2 - 2*tau*vFinal + 
        tau^2*tFinal*vFinal + tau^2*vFinal^2))/(tau*(-1 + tau*tFinal)*
       (-1 + tau*vFinal)*(-1 + tau*tFinal + tau*vFinal))}, 
   {(3*(-2 + 13*eps - 27*eps^2 + 18*eps^3)*(-2 + 5*tau*tFinal - 
       4*tau^2*tFinal^2 + tau^3*tFinal^3 + 4*tau*vFinal - 
       6*tau^2*tFinal*vFinal + 3*tau^3*tFinal^2*vFinal - 2*tau^2*vFinal^2 + 
       2*tau^3*tFinal*vFinal^2))/(eps^2*tau*(-1 + tau*vFinal)*
      (-1 + tau*tFinal + tau*vFinal)*(1 - 2*tau*tFinal + tau^2*tFinal^2 + 
       tau^2*tFinal*vFinal)), (3*(3 - 15*eps + 18*eps^2 - 10*tau*tFinal + 
       50*eps*tau*tFinal - 60*eps^2*tau*tFinal + 12*tau^2*tFinal^2 - 
       60*eps*tau^2*tFinal^2 + 72*eps^2*tau^2*tFinal^2 - 6*tau^3*tFinal^3 + 
       30*eps*tau^3*tFinal^3 - 36*eps^2*tau^3*tFinal^3 + tau^4*tFinal^4 - 
       5*eps*tau^4*tFinal^4 + 6*eps^2*tau^4*tFinal^4 - 6*tau*vFinal + 
       30*eps*tau*vFinal - 36*eps^2*tau*vFinal + 14*tau^2*tFinal*vFinal - 
       70*eps*tau^2*tFinal*vFinal + 84*eps^2*tau^2*tFinal*vFinal - 
       12*tau^3*tFinal^2*vFinal + 60*eps*tau^3*tFinal^2*vFinal - 
       72*eps^2*tau^3*tFinal^2*vFinal + 4*tau^4*tFinal^3*vFinal - 
       20*eps*tau^4*tFinal^3*vFinal + 24*eps^2*tau^4*tFinal^3*vFinal + 
       3*tau^2*vFinal^2 - 15*eps*tau^2*vFinal^2 + 18*eps^2*tau^2*vFinal^2 - 
       4*tau^3*tFinal*vFinal^2 + 20*eps*tau^3*tFinal*vFinal^2 - 
       24*eps^2*tau^3*tFinal*vFinal^2 + 2*tau^4*tFinal^2*vFinal^2 - 
       10*eps*tau^4*tFinal^2*vFinal^2 + 12*eps^2*tau^4*tFinal^2*vFinal^2 - 
       tau^4*tFinal*vFinal^3 + 5*eps*tau^4*tFinal*vFinal^3 - 
       6*eps^2*tau^4*tFinal*vFinal^3))/(2*eps*tau*(-1 + tau*tFinal)*
      (-1 + tau*vFinal)*(-1 + tau*tFinal + tau*vFinal)*
      (1 - 2*tau*tFinal + tau^2*tFinal^2 + tau^2*tFinal*vFinal)), 0, 0, 0, 0, 
    0, (3*eps*(1 - 2*tau*tFinal + tau^2*tFinal^2 - 2*tau*vFinal + 
       tau^2*tFinal*vFinal + tau^2*vFinal^2))/(tau*(-1 + tau*tFinal)*
      (-1 + tau*vFinal)*(-1 + tau*tFinal + tau*vFinal)), 
    (-7*eps + 20*eps*tau*tFinal - 18*eps*tau^2*tFinal^2 + 
      4*eps*tau^3*tFinal^3 + eps*tau^4*tFinal^4 + 17*eps*tau*vFinal - 
      31*eps*tau^2*tFinal*vFinal + 19*eps*tau^3*tFinal^2*vFinal - 
      5*eps*tau^4*tFinal^3*vFinal - 13*eps*tau^2*vFinal^2 + 
      9*eps*tau^3*tFinal*vFinal^2 - eps*tau^4*tFinal^2*vFinal^2 + 
      3*eps*tau^3*vFinal^3 + 2*eps*tau^4*tFinal*vFinal^3)/
     (2*tau*(-1 + tau*tFinal)*(-1 + tau*vFinal)*(-1 + tau*tFinal + 
       tau*vFinal)*(1 - 2*tau*tFinal + tau^2*tFinal^2 - tau*vFinal + 
       2*tau^2*tFinal*vFinal))}}, "RadialResidue" -> 
  {{0, 0, 0, 0, 0, 0, 0, 0, 0}, {-2 + 3*eps, -eps, 0, 0, 0, 0, 0, 0, 0}, 
   {-2 + 3*eps, 0, -eps, 0, 0, 0, 0, 0, 0}, 
   {(2*(-2 + 13*eps - 27*eps^2 + 18*eps^3))/eps^2, 
    (9*(1 - 5*eps + 6*eps^2))/(2*eps), (-3*(1 - 5*eps + 6*eps^2))/(2*eps), 
    -10*eps, -4*eps, eps, -3*eps, 0, 0}, 
   {0, (-9*(1 - 5*eps + 6*eps^2))/(2*eps), 0, 9*eps, 2*eps, -eps, 4*eps, 0, 
    0}, {(-3*(-2 + 13*eps - 27*eps^2 + 18*eps^3))/(2*eps^2), 
    (-3*(1 - 5*eps + 6*eps^2))/(2*eps), (3*(1 - 5*eps + 6*eps^2))/(2*eps), 
    3*eps, 2*eps, -4*eps, eps, 0, 0}, 
   {(-3*(-2 + 13*eps - 27*eps^2 + 18*eps^3))/(2*eps^2), 
    (-3*(1 - 5*eps + 6*eps^2))/(2*eps), (3*(1 - 5*eps + 6*eps^2))/(2*eps), 
    3*eps, 2*eps, -eps, -2*eps, 0, 0}, 
   {(2 - 13*eps + 27*eps^2 - 18*eps^3)/(2*eps^2), (-1 + 5*eps - 6*eps^2)/
     (4*eps), 0, 0, 0, 0, 0, (3*eps)/2, eps/4}, 
   {(-6*(-2 + 13*eps - 27*eps^2 + 18*eps^3))/eps^2, 
    (-9*(1 - 5*eps + 6*eps^2))/(2*eps), 0, 0, 0, 0, 0, -3*eps, (7*eps)/2}}, 
 "TransformedPhysicalSoftVectorOverM2" -> 
  {-(eps/((-1 + 2*eps)*(-2 + 3*eps))), (1 - 2*eps)^(-1), (1 - 2*eps)^(-1), 
   (1 - 3*eps)/(2*eps^2), 0, 0, 0, 0, (-3*(-1 + 3*eps))/(eps*(1 + eps))}, 
 "SoftResidueResidual" -> {0, 0, 0, 0, 0, 0, 0, 
   (3*(-1 + 3*eps))/(4*eps*(1 + eps)), (21*(-1 + 3*eps))/(2*eps*(1 + eps))}, 
 "Checks" -> <|"OriginalChartFlat" -> True, "TransformedChartFlat" -> True, 
   "BlockLowerTriangular" -> True, "DiagonalBlocksEpsilonLinear" -> True, 
   "RadialPathFuchsian" -> True, "PhysicalSoftVectorInResidueKernel" -> 
    False|>|>
