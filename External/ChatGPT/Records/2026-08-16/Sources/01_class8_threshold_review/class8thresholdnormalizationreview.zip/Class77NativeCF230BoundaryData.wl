<|"Object" -> "Class77NativeCF230BoundaryData", 
 "CornerConvention" -> "kc = rho kb, 2 ka.kb = 1, rho -> 0+; cut permutations \
and ka <-> kb identify equivalent physical scalar periods", 
 "Basis" -> {GLI[CF230, {1, 1, 1, 0, 1, 0, 1, 1, 0}], 
   GLI[CF230, {1, 1, 1, 0, 1, 0, 1, 2, 0}], 
   GLI[CF230, {1, 1, 1, 0, 2, 0, 1, 1, 0}], 
   GLI[CF230, {1, 1, 2, 0, 1, 0, 1, 1, 0}], 
   GLI[CF230, {1, 1, 0, 0, 0, 0, 0, 1, 0}], 
   GLI[CF230, {1, 1, 0, 0, 0, 0, 1, 1, 0}], 
   GLI[CF230, {1, 1, 0, 0, 1, 0, 0, 1, 0}], 
   GLI[CF230, {1, 1, 0, 0, 1, 0, 1, 1, 0}], 
   GLI[CF230, {1, 1, 0, 0, 1, 0, 1, 2, 0}], 
   GLI[CF230, {1, 1, 0, 0, 1, 0, 2, 1, 0}], 
   GLI[CF230, {1, 1, 0, 0, 2, 0, 1, 1, 0}], 
   GLI[CF230, {1, 1, 1, 0, 0, 0, 1, 1, 0}], 
   GLI[CF230, {1, 1, 1, 0, 0, 0, 1, 2, 0}]}, 
 "Records" -> {<|"Master" -> GLI[CF230, {1, 1, 1, 0, 1, 0, 1, 1, 0}], 
    "RhoPower" -> 0, "ExactDenominatorNormalization" -> -1, 
    "DonorMaster" -> GLI[CF12, {1, 1, 1, 1, 1, 0, 0, 1, 0}], 
    "DonorRhoPower" -> 0, "BoundaryMasters" -> 
     {GLI[BoundaryTopology1, {1, 1, 2, 0, 0, 0, 0}]}, 
    "BoundaryCoefficient" -> (-3*(-1 + 3*eps)*m2)/(eps*(1 + 2*eps))|>, 
   <|"Master" -> GLI[CF230, {1, 1, 1, 0, 1, 0, 1, 2, 0}], "RhoPower" -> 0, 
    "ExactDenominatorNormalization" -> -1, "DonorMaster" -> 
     GLI[CF12, {1, 1, 1, 1, 1, 0, 0, 2, 0}], "DonorRhoPower" -> 0, 
    "BoundaryMasters" -> {GLI[BoundaryTopology1, {1, 1, 2, 0, 0, 0, 0}]}, 
    "BoundaryCoefficient" -> (-3*(-1 + 3*eps)*(1 + 3*eps)*m2)/(1 + eps)^2|>, 
   <|"Master" -> GLI[CF230, {1, 1, 1, 0, 2, 0, 1, 1, 0}], "RhoPower" -> 0, 
    "ExactDenominatorNormalization" -> 1, "DonorMaster" -> 
     GLI[CF230, {1, 1, 1, 0, 2, 0, 1, 1, 0}], "DonorRhoPower" -> 0, 
    "BoundaryMasters" -> {GLI[BoundaryTopology1, {1, 1, 2, 0, 0, 0, 0}]}, 
    "BoundaryCoefficient" -> (3*(-1 + 3*eps)*(1 + 3*eps)*m2)/
      ((1 + eps)^2*(1 + 2*eps))|>, 
   <|"Master" -> GLI[CF230, {1, 1, 2, 0, 1, 0, 1, 1, 0}], "RhoPower" -> 0, 
    "ExactDenominatorNormalization" -> 1, "DonorMaster" -> 
     GLI[CF197, {1, 1, 1, 2, 0, 1, 1, 0, 0}], "DonorRhoPower" -> 1, 
    "BoundaryMasters" -> {GLI[BoundaryTopology1, {1, 1, 2, 0, 0, 0, 0}]}, 
    "BoundaryCoefficient" -> (3*(-1 + 3*eps)*(1 + 3*eps)*m2)/
      (2*eps*(1 + eps)^2)|>, 
   <|"Master" -> GLI[CF230, {1, 1, 0, 0, 0, 0, 0, 1, 0}], "RhoPower" -> 0, 
    "ExactDenominatorNormalization" -> 1, "DonorMaster" -> 
     GLI[CF1, {1, 1, 0, 0, 1, 0, 0, 0, 0}], "DonorRhoPower" -> 0, 
    "BoundaryMasters" -> {}, "BoundaryCoefficient" -> 
     (eps*m2)/((-1 + 2*eps)*(-2 + 3*eps))|>, 
   <|"Master" -> GLI[CF230, {1, 1, 0, 0, 0, 0, 1, 1, 0}], "RhoPower" -> 0, 
    "ExactDenominatorNormalization" -> -1, "DonorMaster" -> 
     GLI[CF1, {1, 1, 1, 0, 1, 0, 0, 0, 0}], "DonorRhoPower" -> 0, 
    "BoundaryMasters" -> {GLI[BoundaryTopology1, {1, 1, 2, 0, 0, 0, 0}]}, 
    "BoundaryCoefficient" -> -(m2/(-1 + 2*eps))|>, 
   <|"Master" -> GLI[CF230, {1, 1, 0, 0, 1, 0, 0, 1, 0}], "RhoPower" -> 0, 
    "ExactDenominatorNormalization" -> -1, "DonorMaster" -> 
     GLI[CF1, {1, 1, 1, 0, 1, 0, 0, 0, 0}], "DonorRhoPower" -> 0, 
    "BoundaryMasters" -> {GLI[BoundaryTopology1, {1, 1, 2, 0, 0, 0, 0}]}, 
    "BoundaryCoefficient" -> -(m2/(-1 + 2*eps))|>, 
   <|"Master" -> GLI[CF230, {1, 1, 0, 0, 1, 0, 1, 1, 0}], "RhoPower" -> 0, 
    "ExactDenominatorNormalization" -> 1, "DonorMaster" -> 
     GLI[CF12, {1, 1, 1, 0, 0, 1, 0, 1, 0}], "DonorRhoPower" -> 1, 
    "BoundaryMasters" -> {GLI[BoundaryTopology1, {1, 1, 2, 0, 0, 0, 0}]}, 
    "BoundaryCoefficient" -> ((-1 + 3*eps)*m2)/(2*eps^2)|>, 
   <|"Master" -> GLI[CF230, {1, 1, 0, 0, 1, 0, 1, 2, 0}], "RhoPower" -> 0, 
    "ExactDenominatorNormalization" -> 1, "DonorMaster" -> 
     GLI[CF20, {1, 1, 0, 1, 1, 0, 0, 2, 0}], "DonorRhoPower" -> 0, 
    "BoundaryMasters" -> {GLI[BoundaryTopology1, {1, 1, 2, 0, 0, 0, 0}]}, 
    "BoundaryCoefficient" -> (6*(-1 + 3*eps)*m2)/(1 + 2*eps)|>, 
   <|"Master" -> GLI[CF230, {1, 1, 0, 0, 1, 0, 2, 1, 0}], "RhoPower" -> 0, 
    "ExactDenominatorNormalization" -> -1, "DonorMaster" -> 
     GLI[CF20, {1, 1, 0, 1, 2, 0, 0, 1, 0}], "DonorRhoPower" -> 0, 
    "BoundaryMasters" -> {GLI[BoundaryTopology1, {1, 1, 2, 0, 0, 0, 0}]}, 
    "BoundaryCoefficient" -> (-3*(-1 + 3*eps)*m2)/((1 + eps)*(1 + 2*eps))|>, 
   <|"Master" -> GLI[CF230, {1, 1, 0, 0, 2, 0, 1, 1, 0}], "RhoPower" -> 0, 
    "ExactDenominatorNormalization" -> -1, "DonorMaster" -> 
     GLI[CF20, {1, 1, 0, 1, 2, 0, 0, 1, 0}], "DonorRhoPower" -> 0, 
    "BoundaryMasters" -> {GLI[BoundaryTopology1, {1, 1, 2, 0, 0, 0, 0}]}, 
    "BoundaryCoefficient" -> (-3*(-1 + 3*eps)*m2)/((1 + eps)*(1 + 2*eps))|>, 
   <|"Master" -> GLI[CF230, {1, 1, 1, 0, 0, 0, 1, 1, 0}], "RhoPower" -> 0, 
    "ExactDenominatorNormalization" -> 1, "DonorMaster" -> 
     GLI[CF12, {1, 1, 0, 0, 1, 1, 0, 1, 0}], "DonorRhoPower" -> 1, 
    "BoundaryMasters" -> {GLI[BoundaryTopology1, {1, 1, 2, 0, 0, 0, 0}]}, 
    "BoundaryCoefficient" -> ((-1 + 3*eps)*m2)/(eps*(-1 + 2*eps))|>, 
   <|"Master" -> GLI[CF230, {1, 1, 1, 0, 0, 0, 1, 2, 0}], "RhoPower" -> 0, 
    "ExactDenominatorNormalization" -> 1, "DonorMaster" -> 
     GLI[CF12, {1, 1, 1, 1, 0, 0, 0, 2, 0}], "DonorRhoPower" -> 0, 
    "BoundaryMasters" -> {GLI[BoundaryTopology1, {1, 1, 2, 0, 0, 0, 0}]}, 
    "BoundaryCoefficient" -> (3*(-1 + 3*eps)*m2)/(1 + eps)|>}, 
 "BoundaryMaster" -> m2, "BoundaryVector" -> 
  {(-3*(-1 + 3*eps)*m2)/(eps*(1 + 2*eps)), (-3*(-1 + 3*eps)*(1 + 3*eps)*m2)/
    (1 + eps)^2, (3*(-1 + 3*eps)*(1 + 3*eps)*m2)/((1 + eps)^2*(1 + 2*eps)), 
   (3*(-1 + 3*eps)*(1 + 3*eps)*m2)/(2*eps*(1 + eps)^2), 
   (eps*m2)/((-1 + 2*eps)*(-2 + 3*eps)), -(m2/(-1 + 2*eps)), 
   -(m2/(-1 + 2*eps)), ((-1 + 3*eps)*m2)/(2*eps^2), 
   (6*(-1 + 3*eps)*m2)/(1 + 2*eps), (-3*(-1 + 3*eps)*m2)/
    ((1 + eps)*(1 + 2*eps)), (-3*(-1 + 3*eps)*m2)/((1 + eps)*(1 + 2*eps)), 
   ((-1 + 3*eps)*m2)/(eps*(-1 + 2*eps)), (3*(-1 + 3*eps)*m2)/(1 + eps)}, 
 "Checks" -> <|"EveryNativePeriodMatched" -> True, 
   "EveryNativeRhoPowerIsZero" -> True, "EveryReducedExpressionUsesOnlyM2" -> 
    True|>|>
